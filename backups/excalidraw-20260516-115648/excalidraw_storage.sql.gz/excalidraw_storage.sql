--
-- PostgreSQL database dump
--

\restrict ee1ZYTaDevgB6bgeOAKoxB71u29hW4nedao7BuOjYXBrdajmcSe3EZePicmUeTy

-- Dumped from database version 17.7
-- Dumped by pg_dump version 17.7

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: update_excalidraw_updated_at(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_excalidraw_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_excalidraw_updated_at() OWNER TO postgres;

--
-- Name: update_updated_at_column(); Type: FUNCTION; Schema: public; Owner: excalidraw_backend
--

CREATE FUNCTION public.update_updated_at_column() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_updated_at_column() OWNER TO excalidraw_backend;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: excalidraw_scenes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.excalidraw_scenes (
    id character varying(50) NOT NULL,
    json_data jsonb NOT NULL,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.excalidraw_scenes OWNER TO postgres;

--
-- Name: keyv; Type: TABLE; Schema: public; Owner: excalidraw_backend
--

CREATE TABLE public.keyv (
    key character varying(255) NOT NULL,
    value text,
    created_by integer,
    template_id integer,
    created_at_tracked timestamp with time zone DEFAULT now(),
    metadata jsonb DEFAULT '{}'::jsonb
);


ALTER TABLE public.keyv OWNER TO excalidraw_backend;

--
-- Name: COLUMN keyv.created_by; Type: COMMENT; Schema: public; Owner: excalidraw_backend
--

COMMENT ON COLUMN public.keyv.created_by IS 'ID de l''utilisateur qui a créé cette scène';


--
-- Name: COLUMN keyv.template_id; Type: COMMENT; Schema: public; Owner: excalidraw_backend
--

COMMENT ON COLUMN public.keyv.template_id IS 'ID du template utilisé (si créé depuis un template)';


--
-- Name: COLUMN keyv.metadata; Type: COMMENT; Schema: public; Owner: excalidraw_backend
--

COMMENT ON COLUMN public.keyv.metadata IS 'Métadonnées additionnelles (tags, client_id, mission_id, etc.)';


--
-- Name: templates; Type: TABLE; Schema: public; Owner: excalidraw_backend
--

CREATE TABLE public.templates (
    id integer NOT NULL,
    nom character varying(100) NOT NULL,
    description text,
    excalidraw_json jsonb NOT NULL,
    thumbnail_url text,
    categorie character varying(50),
    tags text[],
    created_by integer,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    version integer DEFAULT 1,
    actif boolean DEFAULT true
);


ALTER TABLE public.templates OWNER TO excalidraw_backend;

--
-- Name: TABLE templates; Type: COMMENT; Schema: public; Owner: excalidraw_backend
--

COMMENT ON TABLE public.templates IS 'Templates Excalidraw réutilisables (BMC, PESTEL, SWOT, etc.)';


--
-- Name: COLUMN templates.excalidraw_json; Type: COMMENT; Schema: public; Owner: excalidraw_backend
--

COMMENT ON COLUMN public.templates.excalidraw_json IS 'JSON complet de la scène Excalidraw (avec placeholders)';


--
-- Name: COLUMN templates.tags; Type: COMMENT; Schema: public; Owner: excalidraw_backend
--

COMMENT ON COLUMN public.templates.tags IS 'Tags pour filtrage (ex: strategy, marketing, project_management)';


--
-- Name: utilisateurs; Type: TABLE; Schema: public; Owner: excalidraw_backend
--

CREATE TABLE public.utilisateurs (
    id integer NOT NULL,
    email character varying(255) NOT NULL,
    password_hash character varying(255) NOT NULL,
    nom character varying(100),
    actif boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT now(),
    last_login timestamp with time zone,
    CONSTRAINT email_format CHECK (((email)::text ~* '^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$'::text))
);


ALTER TABLE public.utilisateurs OWNER TO excalidraw_backend;

--
-- Name: TABLE utilisateurs; Type: COMMENT; Schema: public; Owner: excalidraw_backend
--

COMMENT ON TABLE public.utilisateurs IS 'Utilisateurs du système Excalidraw - Gestion via NocoDB';


--
-- Name: COLUMN utilisateurs.password_hash; Type: COMMENT; Schema: public; Owner: excalidraw_backend
--

COMMENT ON COLUMN public.utilisateurs.password_hash IS 'Hash bcrypt du mot de passe (10 rounds minimum)';


--
-- Name: COLUMN utilisateurs.actif; Type: COMMENT; Schema: public; Owner: excalidraw_backend
--

COMMENT ON COLUMN public.utilisateurs.actif IS 'Si false, utilisateur ne peut plus se connecter';


--
-- Name: scenes_with_user; Type: VIEW; Schema: public; Owner: excalidraw_backend
--

CREATE VIEW public.scenes_with_user AS
 SELECT k.key AS scene_id,
    k.value AS scene_data,
    k.created_by,
    u.email AS created_by_email,
    u.nom AS created_by_name,
    k.template_id,
    t.nom AS template_name,
    k.created_at_tracked,
    k.metadata
   FROM ((public.keyv k
     LEFT JOIN public.utilisateurs u ON ((k.created_by = u.id)))
     LEFT JOIN public.templates t ON ((k.template_id = t.id)))
  ORDER BY k.created_at_tracked DESC;


ALTER VIEW public.scenes_with_user OWNER TO excalidraw_backend;

--
-- Name: VIEW scenes_with_user; Type: COMMENT; Schema: public; Owner: excalidraw_backend
--

COMMENT ON VIEW public.scenes_with_user IS 'Vue enrichie des scènes avec infos utilisateur et template';


--
-- Name: templates_id_seq; Type: SEQUENCE; Schema: public; Owner: excalidraw_backend
--

CREATE SEQUENCE public.templates_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.templates_id_seq OWNER TO excalidraw_backend;

--
-- Name: templates_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: excalidraw_backend
--

ALTER SEQUENCE public.templates_id_seq OWNED BY public.templates.id;


--
-- Name: utilisateurs_id_seq; Type: SEQUENCE; Schema: public; Owner: excalidraw_backend
--

CREATE SEQUENCE public.utilisateurs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.utilisateurs_id_seq OWNER TO excalidraw_backend;

--
-- Name: utilisateurs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: excalidraw_backend
--

ALTER SEQUENCE public.utilisateurs_id_seq OWNED BY public.utilisateurs.id;


--
-- Name: templates id; Type: DEFAULT; Schema: public; Owner: excalidraw_backend
--

ALTER TABLE ONLY public.templates ALTER COLUMN id SET DEFAULT nextval('public.templates_id_seq'::regclass);


--
-- Name: utilisateurs id; Type: DEFAULT; Schema: public; Owner: excalidraw_backend
--

ALTER TABLE ONLY public.utilisateurs ALTER COLUMN id SET DEFAULT nextval('public.utilisateurs_id_seq'::regclass);


--
-- Data for Name: excalidraw_scenes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.excalidraw_scenes (id, json_data, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: keyv; Type: TABLE DATA; Schema: public; Owner: excalidraw_backend
--

COPY public.keyv (key, value, created_by, template_id, created_at_tracked, metadata) FROM stdin;
SCENES:3793308620810895	{"value":{"version":2,"source":"test","elements":[]},"expires":null}	\N	\N	2026-05-16 09:30:46.039263+00	{}
SCENES:3195038786063519	{"value":":base64:AAAAAQAAADt7InZlcnNpb24iOjIsImNvbXByZXNzaW9uIjoicGFrb0AxIiwiZW5jcnlwdGlvbiI6IkFFUy1HQ00ifQAAAAx1KcSpGUKVsvvvlmQAAAJi45Z/N03UrFI4M3/MzaRkH5bPn3txsWM8XPIoBZpVaK7bDlz6gAL6wAS1ytNowtqo9Nhaxgs1dP/a8DbHxfg3Lf2RfrSVQaEUDWRguo2CiDbqhrqRbM53t1qleCwWrvW4MIfkzSwCeU99t5IFma7H8JKnhrYsYis7W2XLZ8wZQJu4pXS04ijyP/xynmrchlrtNGd9+DCwzkhKMQNVNIzz5VmJB38SmNJZeRhG75adx9sQwdzvTZR0hjpyFSqOx8D6xx8fSV97pY8mrTq4t4GjM6zO2eSMqRee3IaFflPVwlNlKSmDTNJEza6vEXuJ6aVg4wgRtlFjDFaoSD+CE4S4dpEMXsyxrT/Q5NSXJ9jfZdTZlVQG6EaGQu/BU2uU4hc1LnsqJ0mG/5urrql3vbHXV99pP0ALRsKya9Xbf1rqWjtGKxOFaFm0AdmeiRc7WCf1id//Ysv+RpQMoh79CAeuPQEKpQ7O6JF/7WiMy+Il9/ChRTw+OvOvxFTR1/vBldkvqhyerIb44SuwUT3eTstJxfQQEpffFvJg/qvngeJYio4KNoeTsuD86xEBFx/217V/ZaYdsQzuhBoED3CD7W+J8Q7TSHHX169Lv1+hxcLrC5TOv4NwTPeIPjZ6xrGXBQQZBbZDPc7VTz7yescJIyk1Hu2KTtCo2+HA7gOraAQ8ZL0YtWgOph52vdfTniIc8pNkhJtRkqsZzngwSRbfgo4U0A70UF1EH0TSZMD/attBMqh0xWw8/LDIIOB6QbubX/6rdorbXhyIXsTQa9Rb2BU1AA75nl+0WDt8+vl2ULi3AR9SFg==","expires":null}	\N	\N	2026-05-16 09:30:46.039263+00	{}
SCENES:2266608500896170	{"value":{"version":2,"source":"test","elements":[]},"expires":null}	\N	\N	2026-05-16 09:30:46.039263+00	{}
SCENES:7661116870516462	{"value":{"version":2,"source":"test-traefik-file","elements":[]},"expires":null}	\N	\N	2026-05-16 09:30:46.039263+00	{}
SCENES:000653076501	{"value":{"version":2,"source":"test-backend-simple","elements":[{"type":"rectangle","x":100,"y":100}]},"expires":null}	\N	\N	2026-05-16 09:30:46.039263+00	{}
SCENES:051506391819	{"value":{},"expires":null}	\N	\N	2026-05-16 09:30:46.039263+00	{}
SCENES:419283437694	{"value":{"version":2,"source":"test-final-frontend","elements":[{"type":"text","x":50,"y":50,"text":"Test"}]},"expires":null}	\N	\N	2026-05-16 09:30:46.039263+00	{}
SCENES:725614294279	{"value":{},"expires":null}	\N	\N	2026-05-16 09:30:46.039263+00	{}
SCENES:767250429367	{"value":{"version":2,"source":"test-cors","elements":[]},"expires":null}	\N	\N	2026-05-16 09:30:46.039263+00	{}
SCENES:287623113133	{"value":{"version":2,"source":"test-cors-fixed","elements":[]},"expires":null}	\N	\N	2026-05-16 09:30:46.039263+00	{}
SCENES:575465326523	{"value":{"version":2,"source":"test-final-cors","elements":[]},"expires":null}	\N	\N	2026-05-16 09:30:46.039263+00	{}
SCENES:552578414172	{"value":{"version":2,"source":"test","elements":[]},"expires":null}	\N	\N	2026-05-16 09:30:46.039263+00	{}
SCENES:468355182587	{"value":{"version":2,"source":"test","elements":[]},"expires":null}	\N	\N	2026-05-16 09:30:46.039263+00	{}
SCENES:984953150300	{"value":{},"expires":null}	\N	\N	2026-05-16 09:30:46.039263+00	{}
SCENES:925524612819	{"value":{},"expires":null}	\N	\N	2026-05-16 09:30:46.039263+00	{}
SCENES:759973445285	{"value":{},"expires":null}	\N	\N	2026-05-16 09:30:46.039263+00	{}
SCENES:214923424118	{"value":{"version":2,"source":"test-logs","elements":[{"type":"rectangle"}]},"expires":null}	\N	\N	2026-05-16 09:30:46.039263+00	{}
SCENES:162599682126	{"value":{"version":2,"source":"test-after-rebuild","elements":[{"type":"text","text":"Hello"}]},"expires":null}	\N	\N	2026-05-16 09:30:46.039263+00	{}
SCENES:897801933013	{"value":{"test":true},"expires":null}	\N	\N	2026-05-16 09:30:46.039263+00	{}
SCENES:801241194387	{"value":{"test":"new-build"},"expires":null}	\N	\N	2026-05-16 09:30:46.039263+00	{}
SCENES:676433384219	{"value":{},"expires":null}	\N	\N	2026-05-16 09:30:46.039263+00	{}
SCENES:138107717085	{"value":{},"expires":null}	\N	\N	2026-05-16 09:30:46.039263+00	{}
SCENES:050394699189	{"value":{},"expires":null}	\N	\N	2026-05-16 09:30:46.039263+00	{}
SCENES:317891896088	{"value":{},"expires":null}	\N	\N	2026-05-16 09:30:46.039263+00	{}
SCENES:198398935956	{"value":{},"expires":null}	\N	\N	2026-05-16 09:30:46.039263+00	{}
SCENES:193085115902	{"value":{},"expires":null}	\N	\N	2026-05-16 09:30:46.039263+00	{}
SCENES:297506879308	{"value":{},"expires":null}	\N	\N	2026-05-16 09:30:46.039263+00	{}
SCENES:921633720793	{"value":{},"expires":null}	\N	\N	2026-05-16 09:30:46.039263+00	{}
SCENES:5062476890265854	{"value":":base64:AAAAAQAAADt7InZlcnNpb24iOjIsImNvbXByZXNzaW9uIjoicGFrb0AxIiwiZW5jcnlwdGlvbiI6IkFFUy1HQ00ifQAAAAxYF/8Gi2dvz3h7DBcAAAJlvFxOgI7FwkwnhhunsiWWL3YCYgs5ecwcx1H52LESX5+0FaRnvGq2ieg7y7Bz+rFjQvlBmXfQvL6xJuB5vdgvNrkTqV93yZthvklrTw9MnWwaIbHGaB1Yyr5DjbDaUb4WO648U3/2aa0iwoTj3HpfdmIzg8Thsmg10iNa0nc8zwfDWu9c1EpZzTB0RJX+1KLcXQ7IpY3Jb1VaohLFufPk/GOyIy1lG1r4tPVulPcSlYMoachMShxS4N+m0OopW8w2nbl6Z+fo/nJJSQUGDDPKb7UL9yyyUhnzjFu4T9vbidSlQ+3dCCDpMdETZfWuliuOJQKAS+O4Llp8JRCfIEiGrV54OkItVOwa5TvHhofurZpkM6E7G/CAZf0+rCH2SjUis7aVWM5lBTU0GGnETSir159oju7N4L5nJ4vNR7nuwghGOhNvU8dPCob2B2KdZBkVJv1Q+h1wsaMnvs3SImng+HPvAYvygR2BAjlRmADkyMvF1jH3IeKwxQxkLl/y8IHA7hSOfKwYons/i5bHYGcPqfDT5iyuoZxFdzXRv4e2RZiEaX5whdFkOb00Yq1sE+b43p/hYHveSPXmqRUBW5RCMtRpAj5atr7bIr2QTwiRhbUWfHgFyuhU9nCNMOqGvOpEDrBQSH+inMlDzuQ5ArxaBCOyNeGjOYTLeS/dKP9xeE+JnRU4WSYNkMcZ8mf9J+aWuEelsaM+GxOHoi5IIeb7a+XEhXJgLZbEvUiZL3q6CtebQpDKvqCT2P2V+N6IZeM3dAykLooGt5Ek9bFaGO7lMDU6YvSRDTxNIC6udZvzGqHvXaT+bw==","expires":null}	\N	\N	2026-05-16 09:30:46.039263+00	{}
SCENES:3002023330286994	{"value":":base64:AAAAAQAAADt7InZlcnNpb24iOjIsImNvbXByZXNzaW9uIjoicGFrb0AxIiwiZW5jcnlwdGlvbiI6IkFFUy1HQ00ifQAAAAx2/I9YyomMAAHkis0AAAJhRarnNuJ4Q6jA73v7OnS32BCFAPzoNWOw+tICFvzWjvf4y8YONtmJmLIBOwEmU5ADd7MlD4B7+Ig15bpM59kMcNJRPe+tRveraPMBtkHlPqnvZ22cFiTliUsULgmzZweNEO/fSzjOYYSsxCY5GbMm/4QSb9zAT1B6Et2jqDX7GWtYh9WSYrKw3ljxeO2Xdss47K/CNrfDY6508dO2FrJzqxPMWiw8lZwga+R254EgKIezAk9Bcm5dRhtxfHWHN3ffpydHcNFGBoPshjQtWOzXIJYu+2kWwlg36aOYi4N9nxVh0usdouX3SvWJVNOvNoieUR4hrzr8czNtcmjEcvXAjVJ8dPB7NS2kxxJuG0BL2zkJ6TR3cYtFFSYLGmYaYw6/Z2nPpzmhZ96FuFfiQDsVB8maKEZ/lRmTAsqfS1Cogae2F6lJYHuvJuQIATyuw1hqiUSmgbHk+HbjTqCFOoFgWBIeMq8TtKbfKdqnShpFIE44Ge0YEUAEFzPveeaq6QVBHw4XmNgUOfeBR3N2Roe1wC8TT0q6u1BAuDA2/U1QUh4mSqyuf/TLMvRA9o/+OSt2m4PO7EyTbOpSF1lYTsViw+dFc5LDD1+H/ANwCv7FCI71WOQqUg6Y3YA8XpvjgY5Xy8YwxfzYO0f32FhlUgqqNZaKVQJ8c3FM20u+zd9A5PfTqyVSSm3IuOGnQhCzFBCP/1RAq3dtRtP1DfcpADVKG6mEEfV6d1kaDoFimfUmfs0q89Lq+ThD3/QjkuvBSB1R925Rtr4sab0BmCaGlxmyi6L8QEB87rPdNZmlUEkD0s/I","expires":null}	\N	\N	2026-05-16 09:30:46.039263+00	{}
\.


--
-- Data for Name: templates; Type: TABLE DATA; Schema: public; Owner: excalidraw_backend
--

COPY public.templates (id, nom, description, excalidraw_json, thumbnail_url, categorie, tags, created_by, created_at, updated_at, version, actif) FROM stdin;
\.


--
-- Data for Name: utilisateurs; Type: TABLE DATA; Schema: public; Owner: excalidraw_backend
--

COPY public.utilisateurs (id, email, password_hash, nom, actif, created_at, last_login) FROM stdin;
1	cmartin@agniconsult.fr	$2b$10$.peysn3X9G91qYzcYd49FOlf1wH/i3uN1nlglzkAMrzA1WGnYjiDi	Christophe Martin	t	2026-05-16 09:48:17.594242+00	2026-05-16 09:48:49.862353+00
\.


--
-- Name: templates_id_seq; Type: SEQUENCE SET; Schema: public; Owner: excalidraw_backend
--

SELECT pg_catalog.setval('public.templates_id_seq', 1, false);


--
-- Name: utilisateurs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: excalidraw_backend
--

SELECT pg_catalog.setval('public.utilisateurs_id_seq', 1, true);


--
-- Name: excalidraw_scenes excalidraw_scenes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.excalidraw_scenes
    ADD CONSTRAINT excalidraw_scenes_pkey PRIMARY KEY (id);


--
-- Name: keyv keyv_pkey; Type: CONSTRAINT; Schema: public; Owner: excalidraw_backend
--

ALTER TABLE ONLY public.keyv
    ADD CONSTRAINT keyv_pkey PRIMARY KEY (key);


--
-- Name: templates templates_nom_key; Type: CONSTRAINT; Schema: public; Owner: excalidraw_backend
--

ALTER TABLE ONLY public.templates
    ADD CONSTRAINT templates_nom_key UNIQUE (nom);


--
-- Name: templates templates_pkey; Type: CONSTRAINT; Schema: public; Owner: excalidraw_backend
--

ALTER TABLE ONLY public.templates
    ADD CONSTRAINT templates_pkey PRIMARY KEY (id);


--
-- Name: utilisateurs utilisateurs_email_key; Type: CONSTRAINT; Schema: public; Owner: excalidraw_backend
--

ALTER TABLE ONLY public.utilisateurs
    ADD CONSTRAINT utilisateurs_email_key UNIQUE (email);


--
-- Name: utilisateurs utilisateurs_pkey; Type: CONSTRAINT; Schema: public; Owner: excalidraw_backend
--

ALTER TABLE ONLY public.utilisateurs
    ADD CONSTRAINT utilisateurs_pkey PRIMARY KEY (id);


--
-- Name: idx_excalidraw_scenes_created_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_excalidraw_scenes_created_at ON public.excalidraw_scenes USING btree (created_at DESC);


--
-- Name: idx_keyv_created_at_tracked; Type: INDEX; Schema: public; Owner: excalidraw_backend
--

CREATE INDEX idx_keyv_created_at_tracked ON public.keyv USING btree (created_at_tracked);


--
-- Name: idx_keyv_created_by; Type: INDEX; Schema: public; Owner: excalidraw_backend
--

CREATE INDEX idx_keyv_created_by ON public.keyv USING btree (created_by);


--
-- Name: idx_keyv_template_id; Type: INDEX; Schema: public; Owner: excalidraw_backend
--

CREATE INDEX idx_keyv_template_id ON public.keyv USING btree (template_id);


--
-- Name: idx_templates_actif; Type: INDEX; Schema: public; Owner: excalidraw_backend
--

CREATE INDEX idx_templates_actif ON public.templates USING btree (actif);


--
-- Name: idx_templates_categorie; Type: INDEX; Schema: public; Owner: excalidraw_backend
--

CREATE INDEX idx_templates_categorie ON public.templates USING btree (categorie);


--
-- Name: idx_templates_tags; Type: INDEX; Schema: public; Owner: excalidraw_backend
--

CREATE INDEX idx_templates_tags ON public.templates USING gin (tags);


--
-- Name: idx_utilisateurs_actif; Type: INDEX; Schema: public; Owner: excalidraw_backend
--

CREATE INDEX idx_utilisateurs_actif ON public.utilisateurs USING btree (actif);


--
-- Name: idx_utilisateurs_email; Type: INDEX; Schema: public; Owner: excalidraw_backend
--

CREATE INDEX idx_utilisateurs_email ON public.utilisateurs USING btree (email);


--
-- Name: excalidraw_scenes trg_excalidraw_scenes_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trg_excalidraw_scenes_updated_at BEFORE UPDATE ON public.excalidraw_scenes FOR EACH ROW EXECUTE FUNCTION public.update_excalidraw_updated_at();


--
-- Name: templates update_templates_updated_at; Type: TRIGGER; Schema: public; Owner: excalidraw_backend
--

CREATE TRIGGER update_templates_updated_at BEFORE UPDATE ON public.templates FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: keyv keyv_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: excalidraw_backend
--

ALTER TABLE ONLY public.keyv
    ADD CONSTRAINT keyv_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.utilisateurs(id);


--
-- Name: keyv keyv_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: excalidraw_backend
--

ALTER TABLE ONLY public.keyv
    ADD CONSTRAINT keyv_template_id_fkey FOREIGN KEY (template_id) REFERENCES public.templates(id);


--
-- Name: templates templates_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: excalidraw_backend
--

ALTER TABLE ONLY public.templates
    ADD CONSTRAINT templates_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.utilisateurs(id);


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: pg_database_owner
--

GRANT ALL ON SCHEMA public TO excalidraw_backend;


--
-- Name: TABLE excalidraw_scenes; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.excalidraw_scenes TO excalidraw_backend;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: public; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON TABLES TO excalidraw_backend;


--
-- PostgreSQL database dump complete
--

\unrestrict ee1ZYTaDevgB6bgeOAKoxB71u29hW4nedao7BuOjYXBrdajmcSe3EZePicmUeTy

